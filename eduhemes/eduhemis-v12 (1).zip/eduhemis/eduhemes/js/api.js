/* ============================================
   EduHemis - Backend API ulagich
   localStorage o'rniga Node.js API ga murojaat
   ============================================ */

const API_URL = 'http://localhost:5000/api';

// ============================================
// 1. ASOSIY SO'ROV FUNKSIYASI
// ============================================
const Api = {

  // Token olish
  getToken() {
    return localStorage.getItem('edu_token');
  },

  // Token saqlash
  setToken(token) {
    localStorage.setItem('edu_token', token);
  },

  // Token o'chirish
  removeToken() {
    localStorage.removeItem('edu_token');
    localStorage.removeItem('edu_user');
  },

  // Foydalanuvchini saqlash
  setUser(user) {
    localStorage.setItem('edu_user', JSON.stringify(user));
  },

  // Foydalanuvchini olish
  getUser() {
    try {
      return JSON.parse(localStorage.getItem('edu_user'));
    } catch {
      return null;
    }
  },

  // Umumiy so'rov
  async request(method, path, body = null) {
    const headers = { 'Content-Type': 'application/json' };
    const token = this.getToken();
    if (token) headers['Authorization'] = `Bearer ${token}`;

    const options = { method, headers };
    if (body) options.body = JSON.stringify(body);

    try {
      const res = await fetch(`${API_URL}${path}`, options);
      const data = await res.json();

      if (res.status === 401) {
        // Token muddati tugagan — loginga qaytarish
        this.removeToken();
        window.location.reload();
        return null;
      }

      return data;
    } catch (err) {
      console.error('❌ API xato:', err);
      return { success: false, message: 'Server bilan aloqa yo\'q. Backend ishlaptyaptimi?' };
    }
  },

  get:    (path)        => Api.request('GET',    path),
  post:   (path, body)  => Api.request('POST',   path, body),
  put:    (path, body)  => Api.request('PUT',    path, body),
  delete: (path)        => Api.request('DELETE', path),
};

// ============================================
// 2. AUTH API
// ============================================
const AuthApi = {

  async login(username, password) {
    const res = await Api.post('/auth/login', { username, password });
    if (res && res.success) {
      Api.setToken(res.token);
      Api.setUser(res.user);
    }
    return res;
  },

  async me() {
    return await Api.get('/auth/me');
  },

  async logout() {
    await Api.post('/auth/logout');
    Api.removeToken();
  },

  isLoggedIn() {
    return !!Api.getToken();
  },

  getCurrentUser() {
    return Api.getUser();
  }
};

// ============================================
// 3. TALABALAR API
// ============================================
const StudentsApi = {
  getAll:  (params = '') => Api.get(`/students${params}`),
  getById: (id)          => Api.get(`/students/${id}`),
  create:  (data)        => Api.post('/students', data),
  update:  (id, data)    => Api.put(`/students/${id}`, data),
  delete:  (id)          => Api.delete(`/students/${id}`),
  getGrades: (id)        => Api.get(`/students/${id}/grades`),
  getTasks:  (id)        => Api.get(`/students/${id}/tasks`),
};

// ============================================
// 4. O'QITUVCHILAR API
// ============================================
const TeachersApi = {
  getAll:    (params = '') => Api.get(`/teachers${params}`),
  getById:   (id)          => Api.get(`/teachers/${id}`),
  create:    (data)        => Api.post('/teachers', data),
  update:    (id, data)    => Api.put(`/teachers/${id}`, data),
  delete:    (id)          => Api.delete(`/teachers/${id}`),
  getLessons:(id)          => Api.get(`/teachers/${id}/lessons`),
  getTasks:  (id)          => Api.get(`/teachers/${id}/tasks`),
};

// ============================================
// 5. BAHOLAR API
// ============================================
const GradesApi = {
  getAll:  (params = '') => Api.get(`/grades${params}`),
  getById: (id)          => Api.get(`/grades/${id}`),
  create:  (data)        => Api.post('/grades', data),
  update:  (id, data)    => Api.put(`/grades/${id}`, data),
  delete:  (id)          => Api.delete(`/grades/${id}`),
  getStats:()            => Api.get('/grades/stats/summary'),
};

// ============================================
// 6. VAZIFALAR API
// ============================================
const TasksApi = {
  getAll:  (params = '') => Api.get(`/tasks${params}`),
  getById: (id)          => Api.get(`/tasks/${id}`),
  create:  (data)        => Api.post('/tasks', data),
  update:  (id, data)    => Api.put(`/tasks/${id}`, data),
  delete:  (id)          => Api.delete(`/tasks/${id}`),
  submit:  (id, data)    => Api.post(`/tasks/${id}/submit`, data),
  grade:   (taskId, studentId, data) => Api.post(`/tasks/${taskId}/grade/${studentId}`, data),
};

// ============================================
// 7. DARSLAR API
// ============================================
const LessonsApi = {
  getAll:      (params = '') => Api.get(`/lessons${params}`),
  getById:     (id)          => Api.get(`/lessons/${id}`),
  create:      (data)        => Api.post('/lessons', data),
  update:      (id, data)    => Api.put(`/lessons/${id}`, data),
  delete:      (id)          => Api.delete(`/lessons/${id}`),
  setAttendance:(id, data)   => Api.post(`/lessons/${id}/attendance`, data),
  getToday:    ()            => Api.get('/lessons/schedule/today'),
};

// ============================================
// 8. FOYDALANUVCHILAR API
// ============================================
const UsersApi = {
  getAll:  (params = '') => Api.get(`/users${params}`),
  getById: (id)          => Api.get(`/users/${id}`),
  create:  (data)        => Api.post('/users', data),
  update:  (id, data)    => Api.put(`/users/${id}`, data),
  delete:  (id)          => Api.delete(`/users/${id}`),
};

// ============================================
// 9. DataBase ni API bilan almashtirish
//    (eski kod ishlashda davom etsin)
// ============================================
const DataBase = {
  users: [], students: [], teachers: [],
  grades: [], tasks: [], lessons: [],

  async load() {
    try {
      if (!AuthApi.isLoggedIn()) return false;

      const [s, t, g, tk, l] = await Promise.all([
        StudentsApi.getAll(),
        TeachersApi.getAll(),
        GradesApi.getAll(),
        TasksApi.getAll(),
        LessonsApi.getAll(),
      ]);

      this.students = s?.students  || [];
      this.teachers = t?.teachers  || [];
      this.grades   = g?.grades    || [];
      this.tasks    = tk?.tasks    || [];
      this.lessons  = l?.lessons   || [];

      // users = students + teachers birlashtirish
      this.users = [
        ...this.students.map(s => ({...s, role: 'student'})),
        ...this.teachers.map(t => ({...t, role: 'teacher'})),
      ];

      console.log('✅ Ma\'lumotlar API dan yuklandi');
      return true;
    } catch (err) {
      console.error('❌ Yuklashda xato:', err);
      return false;
    }
  },

  // Eski save() — endi kerak emas, API avtomatik saqlaydi
  save() {
    console.log('ℹ️ save() chaqirildi — API avtomatik saqlaydi');
  },

  updateStatistics() {
    this.statistics = {
      totalStudents: this.students.length,
      totalTeachers: this.teachers.length,
      totalGrades:   this.grades.length,
      totalTasks:    this.tasks.length,
      totalLessons:  this.lessons.length,
    };
  }
};

// ============================================
// 10. LOGIN FUNKSIYASINI ALMASHTIRISH
// ============================================

  // Yuklash ko'rsatkichi
  const btn = document.getElementById('loginBtn');
  if (btn) { btn.disabled = true; btn.textContent = 'Kirish...'; }

  const res = await AuthApi.login(username, password);

  if (btn) { btn.disabled = false; btn.textContent = 'Kirish'; }

  if (res && res.success) {
    const user = res.user;

    // Ma'lumotlarni yuklash
    await DataBase.load();

    // UI ni yangilash
    document.getElementById('loginPage')?.classList.add('hidden');
    document.getElementById('mainApp')?.classList.remove('hidden');

    if (typeof updateUserInfo === 'function') updateUserInfo(user);
    if (typeof loadDashboard  === 'function') loadDashboard();

    showSuccess(`Xush kelibsiz, ${user.name}! 👋`);
  } else {
    showError(res?.message || 'Login yoki parol noto\'g\'ri');
  }
}

// ============================================
// 11. LOGOUT
// ============================================

// ============================================
// 12. SAHIFA YUKLANGANDA — AVTOMATIK KIRISH
// ============================================
document.addEventListener('DOMContentLoaded', async () => {
  if (AuthApi.isLoggedIn()) {
    const user = AuthApi.getCurrentUser();
    if (user) {
      await DataBase.load();
      document.getElementById('loginPage')?.classList.add('hidden');
      document.getElementById('mainApp')?.classList.remove('hidden');
      if (typeof updateUserInfo === 'function') updateUserInfo(user);
      if (typeof loadDashboard  === 'function') loadDashboard();
    }
  }
});

// ============================================
// 13. GLOBAL
// ============================================
window.Api         = Api;
window.AuthApi     = AuthApi;
window.StudentsApi = StudentsApi;
window.TeachersApi = TeachersApi;
window.GradesApi   = GradesApi;
window.TasksApi    = TasksApi;
window.LessonsApi  = LessonsApi;
window.UsersApi    = UsersApi;
window.DataBase    = DataBase;
